CREATE VIEW spa_acc as
  select i.name, i.alias, i.qty
  from indentList i,
       spaSearchList p
  where i.alias like p.name
  except
  select i.name, i.alias, i.qty
  from indentList i,
       rcSearchList p
  where i.alias like p.name
  except
  select * from gpa_acc;


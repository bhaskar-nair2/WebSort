CREATE VIEW tem as
select *
from spa_acc union select * from gpa_acc;


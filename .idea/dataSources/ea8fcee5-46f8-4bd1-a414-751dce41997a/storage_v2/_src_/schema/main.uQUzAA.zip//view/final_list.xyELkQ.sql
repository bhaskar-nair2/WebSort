CREATE VIEW final_list as
  select p.contract, i.name, p.rate, i.qty, p.supplier
  from spa_acc i,
       spaSearchList p
  where i.alias = p.name
  union
  select p.contract, i.name, p.rate, i.qty, p.supplier
  from gpa_acc i,
       gpaSearchList p
  where i.alias = p.name
  union
  select *
  from rc_acc;


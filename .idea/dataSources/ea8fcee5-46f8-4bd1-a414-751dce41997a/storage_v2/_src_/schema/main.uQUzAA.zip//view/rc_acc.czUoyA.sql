CREATE VIEW rc_acc as
  select p.contract, i.name, p.rate, i.qty, p.supplier
  from indentList i,
       rcSearchList p
  where i.alias like p.name;


CREATE VIEW not_found as select * from indentList  where name not in (select final_list.name from final_list);

